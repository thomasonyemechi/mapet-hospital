@extends('layout.app')
@section('page_title')
    View Invoice
@endsection

@php

    $client = $summary->client;
@endphp

@section('page_content')
    <div class="row">

        <div class="col-lg-12 col-md-12 col-12">
            <div class=" pb-4 mb-2 d-flex justify-content-between align-items-center">
                <div class="mb-2 mb-lg-0">
                    <h1 class="mb-1 h2 fw-bold">
                        View invoice
                    </h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">View Invoice</a></li>
                            <li class="breadcrumb-item active" aria-current="page">
                                {{ $summary->invoice_number }}
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>



        <div class="col-md-12  ">
            @php
                $client = $summary->client;
            @endphp



            <div class="m-3">
                <div class="row">


                    <div class="col-md-12">





                        <div class="card">
                            <div class="card-body">
                                <div class="mb-2 d-flex justify-content-end " >
                                    <button class="btn btn-primary me-2" > <i class="fe fe-edit" ></i> Edit Invoice</button>
                                    <button class="btn btn-info me-2" > <i class="fe fe-credit" ></i> Make Payment</button>
                                    <button class="btn btn-dark-info me-2" > <i class="fe fe-printer" ></i> Print Invoice</button>
                                    <a class="btn btn-danger" onclick="return confrim('Invovice and payment will be deleted')"  > <i class="fe fe-trash" ></i> Delete Invoice</a>
                                </div>


                                <div class="invoice-bg-2 fw-bold mb-3 p-3" style="font-size: 18px;">
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="d-flex text-m justify-content-between ">
                                                <span>Date:</span>
                                                <span> {{ date('j M Y ', strtotime($summary->created_at)) }}</span>
                                            </div>
                                        </div>

                                        <div class="col-6">
                                            <div class="d-flex text-m justify-content-between ">
                                                <span>Invoice:</span>
                                                <span> {{ $summary->invoice_number }} </span>
                                            </div>
                                        </div>

                                    </div>
                                </div>



                                <div class="row">


                                    <div class="col-md-12">
                                        <div class="card">
                                            <div class="card-body">
                                                <h4 class="fw-bold" style="text-decoration: underline">Patient Details</h4>
                                                <div class="row mb-2">
                                                    <div class="col-md-4">
                                                        <div class="d-flex justify-content-between">
                                                            <span>Full Name</span> <span>:</span>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-8">
                                                        <span class="fw-bold">
                                                            {{ $client->lastname . ' ' . $client->lastname }}
                                                        </span>

                                                    </div>
                                                </div>


                                                <div class="row mb-2">
                                                    <div class="col-md-4">
                                                        <div class="d-flex justify-content-between">
                                                            <span>UPN</span> <span>:</span>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-8">
                                                        <span class="fw-bold"> {{ $client->upn }} </span>
                                                    </div>
                                                </div>

                                 
                                

                                            </div>
                                        </div>
                                    </div>



                                </div>

                                <div class="table-responsive shadow-lg mt-3 " style="border-radius: 5px;">
                                    <table class="table table-bordered table-sm mb-0  invoice-table  ">
                                        <thead class="invoice-bg">
                                            <tr>
                                                <th>Hospital Service</th>
                                                <th>Qty</th>
                                                <th>Rate</th>
                                                <th>
                                                    <div class="d-flex justify-content-end">
                                                        Amount
                                                    </div>
                                                </th>
                                            </tr>
                                        </thead>

                                        <tbody class="cart_list">
                                            @foreach ($summary->items as $item)
                                                <tr>
                                                    <td class="align-middle">
                                                        <a href="javascript:;">
                                                            <h4 class="fw-bold m-0 p-0 text-info"> {{ $item->item_name }}
                                                            </h4>
                                                        </a>
                                                    </td>
                                                    <td class="align-middle">
                                                        <h3 class="fw-bold  fs-4 text-m m-0 p-0">
                                                            {{ $item->qty }} </h3>
                                                    </td>
                                                    <td class="align-middle">
                                                        <span class="fw-bold fs-4 text-m m-0 p-0">
                                                            {{ money($item->rate) }} </span>
                                                    </td>
                                                    <td>
                                                        <div class="d-flex justify-content-end">
                                                            <span class="fw-bold fs-4 text-dark   mt-1">
                                                                {{ money($item->rate * $item->qty) }} </span>

                                                        </div>
                                                    </td>
                                                </tr>
                                            @endforeach

                                        </tbody>
                                    </table>
                                </div>

                                <div class="table-responsive shadow-lg mt-3 " style="border-radius: 5px;">
                                    <table class="table table-bordered mb-0 invoice-table table-sm ">
                                        <thead class="invoice-bg">
                                            <tr>
                                                <th>Total Amount</th>
                                                <th>Initial Deposit</th>
                                                <th>Outstanding Balance</th>
                                                <th>30days</th>
                                            </tr>
                                        </thead>

                                        <tbody>

                                            <tr>
                                                <td class="align-middle">
                                                    <h3 class="fs-3 fw-bold text-m m-0 p-0"> {{ money($summary->total) }}
                                                    </h3>
                                                </td>

                                                <td>
                                                    <h3 class="fs-3 fw-bold text-m m-0 p-0">
                                                        {{ money($summary->initial_deposit) }} </h3>
                                                </td>
                                                <td>
                                                    <h3 class="fs-3 fw-bold text-m m-0 p-0">
                                                        {{ money($summary->outstanding_balance) }} </h3>
                                                </td>
                                                <td>
                                                    <h3 class="fs-3 fw-bold text-m m-0 p-0">{{ $summary->days }} </h3>
                                                </td>
                                            </tr>
                                        </tbody>

                                    </table>

                                </div>
                            
                            </div>
                        </div>
                    </div>


                </div>
            </div>

        </div>
    </div>
@endsection



@push('scripts')
@endpush
