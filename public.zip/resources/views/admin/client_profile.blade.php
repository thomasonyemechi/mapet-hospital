@extends('layout.admin')
@section('page_title')
    Patient Profile | {{ $user->name }}
@endsection



@section('page_content')
    <div class="col-xl-12">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-12">
                <div class=" pb-4 mb-2 d-flex justify-content-between align-items-center">
                    <div class="mb-2 mb-lg-0">
                        <h1 class="mb-1 h2 fw-bold">
                            Patient Profile
                        </h1>
                        <!-- Breadcrumb  -->
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="#">Patients </a>
                                </li>
                                <li class="breadcrumb-item">
                                    <a href="#">
                                        {{ $user->title . ' ' . $user->lastname . ' ' . $user->firstname }}</a>
                                </li>
                            </ol>
                        </nav>
                    </div>
                    <div class="nav btn-group" role="tablist">
                        <div class="input-group me-3  ">

                            <select name="" class="form-control flatpickr-input ">
                                <option value="">Select Client</option>
                            </select>

                        </div>
                    </div>
                </div>
            </div>



            <div class="col-md-12">
                <div class="card mb-3">
                    <div class="card-header d-flex justify-content-between  ">
                        <h5 class="mb-0 fw-bold ">Patient Details</h5>
                        {{-- <button class="btn btn-primary py-0">Update Info</button> --}}
                    </div>

                    <div class="card-body">

                        <div class="row">
                            <div class="col-md-4">
                                <div class="d-flex justify-content-st ">
                                    <div class="me-5">
                                        <img src="{{ Avatar::create(strtoupper($user->firstname . ' ' . $user->lastname))->toBase64() }}"
                                            style="" />

                                    </div>
                                    <div>
                                        <h2 class="fw-bold mb-0">
                                            {{ $user->title . ' ' . $user->lastname . ' ' . $user->firstname }}
                                        </h2>
                                        <span class="text-primary small" style="line-height: 1px !important">
                                            {{ $user->address }} </span>
                                        <div class="small fs-4 fw-bold  m-0 p-0"> ({{ $user->age }} years) </div>
                                        <span>Patient ID : <span class="badge bg-secondary"> {{ 'MAP/' . $user->id }}
                                            </span>
                                            | UPN <span class="badge bg-primary" >{{ $user->upn }}</span>
                                        </span>
                                        <div> Emergency Contact: <span class="fw-bold">{{ $user->emergency_contact }}</span>
                                        </div>
                                    </div>
                                </div>



                            </div>
                            <div class="col-md-8">

                                <div class="row ">
                                    <div class="col-md-6">

                                        <div class="d-flex justify-content-between border-bottom py-2">
                                            <span>Phone</span>
                                            <span class="text-warning">
                                                {{ $user->phone }}
                                            </span>
                                        </div>
                                        <div class="d-flex justify-content-between border-bottom py-2">
                                            <span>Email</span>
                                            <span>
                                                {{ $user->email }}
                                            </span>
                                        </div>
                                        <div class="d-flex justify-content-between border-bottom py-2">
                                            <span>UPN</span>
                                            <span>
                                                {{ $user->upn }}
                                            </span>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="d-flex justify-content-between border-bottom py-2">
                                            <span>Blood Group</span>
                                            <span class="text-warning">
                                                {{ $user->blood_group }}
                                            </span>
                                        </div>
                                        <div class="d-flex justify-content-between border-bottom py-2">
                                            <span>Blood Pressure</span>
                                            <span>
                                                {{ $user->blood_pressure }}
                                            </span>
                                        </div>
                                        <div class="d-flex justify-content-between border-bottom py-2">
                                            <span>Height</span>
                                            <span>
                                                {{ $user->height }}
                                            </span>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>
            </div>


            <div class="col-lg-12 col-md-12 col-12">
                <div class="card mb-3 ">
                    <div class="card-body">
                        <h4 class="fw-bold">Quick Actions</h4>
                        <div class="d-flex">
                            <a href="/invoice/new/{{ $user->id }}"
                                class="btn btn-dark-primary me-2 shadow-sm py-2 ">Create New Invoice</a>

                            <button class="btn btn-dark-secondary me-2 shadow-sm py-2 ">Add New Payment</button>
                            <button class="btn btn-primary shadow-sm me-2 py-2 ">Edit Patient Profile</button>
                        </div>
                    </div>
                </div>
                <div class="card rounded-3">

                    <div class="row">
                        <div class="col-md-12 mt-3 mb-4">
                            <!-- Nav -->
                            <ul class="nav" id="tab" role="tablist">
                                <li class="me-3  mx-3 ">
                                    <a class=" btn btn-secondary active" id="profile-tab" data-bs-toggle="pill"
                                        href="#profile" role="tab" aria-controls="profile" aria-selected="false">Profile
                                        Overview</a>
                                </li>
                                <li class="me-3">
                                    <a class=" btn btn-secondary" id="invoice-tab" data-bs-toggle="pill" href="#invoice"
                                        role="tab" aria-controls="invoice" aria-selected="false">Admission Cards</a>
                                </li>
                                <li class="me-3">
                                    <a class=" btn btn-secondary" id="invoice-tab" data-bs-toggle="pill" href="#invoice"
                                        role="tab" aria-controls="invoice" aria-selected="false">Patient Invoices</a>
                                </li>
                                <li class="me-3 ">
                                    <a class=" btn btn-secondary" id="payments-tab" data-bs-toggle="pill" href="#payments"
                                        role="tab" aria-controls="payments" aria-selected="false">Payments</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div>
                        <div class="tab-content p-3" id="tabContent">
                            <div class="tab-pane active show" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                                <div class="card border-0 shadow-lg">
                                    <div class="card-body">
                                        <div class="d-flex justify-content-between border-bottom py-2">
                                            <span>Phone</span>
                                            <span class="text-warning">
                                                {{ $user->phone }}
                                            </span>
                                        </div>
                                        <div class="d-flex justify-content-between border-bottom py-2">
                                            <span>Email</span>
                                            <span>
                                                {{ $user->email }}
                                            </span>
                                        </div>
                                        <div class="d-flex justify-content-between border-bottom py-2">
                                            <span>UPN</span>
                                            <span>
                                                {{ $user->upn }}
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!--Tab pane -->
                            <div class="tab-pane fade " id="payments" role="tabpanel" aria-labelledby="payments-tab">

                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
@endsection


@push('scripts')
    <script>
        $(function() {
            //$('#modify_userhours').modal('show');
        })
    </script>
@endpush
