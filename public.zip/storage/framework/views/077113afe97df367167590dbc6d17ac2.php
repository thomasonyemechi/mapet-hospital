
<?php $__env->startSection('page_title'); ?>
    Manage Client
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_content'); ?>
    <div class="row">
        <div class="col-lg-12 col-md-12 col-12">
            <div class=" pb-4 mb-2 d-flex justify-content-between align-items-center">
                <div class="mb-2 mb-lg-0">
                    <h1 class="mb-1 h2 fw-bold">
                        New Patient Profile
                    </h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">Patient</a></li>
                            <li class="breadcrumb-item active" aria-current="page">
                                New Patient
                            </li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>


        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    <form method="POST" class="row" accept="/admin/client/new-client">
                        <?php echo csrf_field(); ?>
                        <div class="col-md-12">
                            <div class="card mb-2 ">
                                <div class="card-body">
                                    <h4 class="fw-bold p-0 text-decoration-underline  ">Patient Details</h4>

                                    <div class="row">
                                        <div class="col-md-2 mb-3 mb-2 ">
                                            <label class="form-label">Title<span class="text-danger">*</span></label>
                                            <select name="title" class="form-control">
                                                <option selected disabled>...</option>
                                                <option>Mr</option>
                                                <option>Mrs</option>
                                                <option>Miss</option>
                                            </select>
                                        </div>
                                        <div class="col-md-10">
                                            <div class="row">
                                                <div class="col-md-4 mb-3 mb-2 ">
                                                    <label class="form-label">First Name<span
                                                            class="text-danger">*</span></label>
                                                    <input type="text" name="firstname" value="<?php echo e(old('firstname')); ?>"
                                                        class="form-control" placeholder="First Name" required>
                                                    <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="small text-danger"><?php echo e($message); ?> </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                                <div class="col-md-4 mb-3 mb-2 ">
                                                    <label class="form-label">Last Name<span
                                                            class="text-danger">*</span></label>
                                                    <input type="text" name="lastname" value="<?php echo e(old('lastname')); ?>"
                                                        class="form-control" placeholder="Enter last name" required>
                                                    <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="small text-danger"><?php echo e($message); ?> </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>

                                                <div class="col-md-4 mb-3 mb-2 ">
                                                    <label class="form-label">Other Names<span
                                                            class="text-danger">*</span></label>
                                                    <input type="text" name="other_names"
                                                        value="<?php echo e(old('other_names')); ?>" class="form-control"
                                                        placeholder="other names" required>
                                                    <?php $__errorArgs = ['other_names'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="small text-danger"><?php echo e($message); ?> </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                        </div>


                                        <div class="col-md-2 mb-3 mb-2 ">
                                            <label class="form-label">UPN<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control " value="<?php echo e(old('upn')); ?>"
                                                name="upn">
                                        </div>


                                        <div class="col-md-4 mb-3 mb-2 ">
                                            <label class="form-label">Phone</label>
                                            <input type="text" name="phone" class="form-control"
                                                placeholder="Enter phone number" value="<?php echo e(old('phone')); ?>">
                                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="small text-danger"><?php echo e($message); ?> </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="col-md-4 mb-3 mb-2 ">
                                            <label class="form-label">Email</label>
                                            <input type="text" name="email" class="form-control"
                                                value="<?php echo e(old('email')); ?>" placeholder="Enter Email Address">
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="small text-danger"><?php echo e($message); ?> </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="col-md-2 mb-3 mb-2 ">
                                            <label class="form-label">Age<span class="text-danger">*</span></label>
                                            <input type="number" name="age" class="form-control"
                                                value="<?php echo e(old('age')); ?>" placeholder="Enter age" required>
                                            <?php $__errorArgs = ['age'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="small text-danger"><?php echo e($message); ?> </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>

                                        <div class="col-md-2 mb-3 mb-2 ">
                                            <label class="form-label">Gender<span class="text-danger">*</span></label>
                                            <select class="form-control" name="gender">
                                                <option>Male</option>
                                                <option>Female</option>
                                            </select>
                                        </div>


                                        <div class="col-md-3 mb-3 mb-2 ">
                                            <label class="form-label">organization</label>
                                            <input type="text" name="organization" <?php echo e(old('organization')); ?>

                                                class="form-control" placeholder="">
                                        </div>




                                        <div class="col-md-3 mb-3 mb-2 ">
                                            <label class="form-label">LGA</label>
                                            <input type="text" name="lga" value="<?php echo e(old('lga')); ?>"
                                                class="form-control" placeholder="">
                                        </div>




                                        <div class="col-md-4 mb-3 mb-2 ">
                                            <label class="form-label">How did you hear about us </label>
                                            <select name="" class="form-control" id="">
                                                <option>Family/Friend Recomendation</option>
                                                <option>Social Media / Online</option>
                                                <option>Victri Outreach</option>
                                                <option>Referral Through medical Prefessional</option>
                                                <option>Referral from a pharmacy</option>
                                                <option> Beneficiary Staff Member</option>
                                                <option>NHIS/HMO Programs</option>
                                                <option>Others</option>
                                            </select>
                                        </div>

                                        <div class="col-lg-12 mb-3 mb-3">
                                            <label class="form-label">Home Address</label>
                                            <textarea name="address" class="form-control" rows="1"> <?php echo e(old('address')); ?> </textarea>

                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card mb-2">
                                <div class="card-body">
                                    <h4 class="fw-bold text-decoration-underline">Emergency Contact</h4>

                                    <div class="row">
                                        <div class="col-md-3 mb-3 mb-2 ">
                                            <label class="form-label">Surname</label>
                                            <input type="text" name="emergency_surname"
                                                value="<?php echo e(old('emergency_surname')); ?>" class="form-control"
                                                placeholder="">
                                        </div>
                                        <div class="col-md-3 mb-3 mb-2 ">
                                            <label class="form-label">Firstname</label>
                                            <input type="text" name="emergency_firstname"
                                                value="<?php echo e(old('emergency_firstname')); ?>" class="form-control"
                                                placeholder="">
                                        </div>


                                        <div class="col-md-3 mb-3 mb-2 ">
                                            <label class="form-label">Contact</label>
                                            <input type="text" name="emergency_contact" value="<?php echo e(old('address')); ?>"
                                                class="form-control" placeholder="">
                                        </div>
                                        <div class="col-md-3 mb-3 mb-2 ">
                                            <label class="form-label">Relationship to Patient</label>
                                            <input type="text" name="relationship" value="<?php echo e(old('relationship')); ?>"
                                                class="form-control" placeholder="">
                                        </div>


                                    </div>

                                </div>
                            </div>


                            <div class="card mb-2">
                                <div class="card-body">
                                    <h4 class="fw-bold text-decoration-underline">Card Type</h4>

                                    <div class="row">
                                        <div class="d-flex justify-content-between">
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="card_type"
                                                    id="flexRadioDefault1" name="single" checked>
                                                <label class="form-check-label" for="flexRadioDefault1">
                                                    Single
                                                </label>
                                            </div>
                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="card_type"
                                                    id="flexRadioDefault2" value="family">
                                                <label class="form-check-label" for="flexRadioDefault2">
                                                    Family
                                                </label>
                                            </div>

                                            <div class="form-check">
                                                <input class="form-check-input" type="radio" name="card_type"
                                                    id="flexRadioDefault3" value="maternity">
                                                <label class="form-check-label" for="flexRadioDefault3">
                                                    Maternity
                                                </label>
                                            </div>
                                        </div>


                                    </div>

                                </div>
                            </div>


                            <div class="card mb-2">
                                <div class="card-body">
                                    <h4 class="fw-bold text-decoration-underline">Other Details</h4>

                                    <div class="row">

                                        <div class="col-md-2 mb-3 mb-2 ">
                                            <label class="form-label">Blood Group</label>
                                            <input type="text" name="blood_group" value="<?php echo e(old('blood_group')); ?>"
                                                class="form-control" placeholder="">
                                        </div>

                                        <div class="col-md-2 mb-3 mb-2 ">
                                            <label class="form-label">Genotype</label>
                                            <input type="text" name="genoytpe" value="<?php echo e(old('genoytpe')); ?>"
                                                class="form-control" placeholder="">
                                        </div>



                                    </div>

                                </div>
                            </div>

                            <button class="btn btn-primary w-100">
                                Create Patient Profile
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="row">
                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xl-6 col-lg-6 col-sm-6">
                        <div class="card contact_list mb-2 text-center">
                            <div class="card-body">

                                <div class="user-content">
                                    <div class="user-info">
                                        <div class="user-img">
                                            <a href="<?php echo e($client->id); ?>">
                                                <img src="<?php echo e(Avatar::create($client->lastname . ' ' . $client->firstname)->toBase64()); ?>"
                                                    class="rounded-circle " style="width: 35px" />
                                            </a>
                                        </div>
                                        <div class="user-details mt-2">
                                            <a href="/client/<?php echo e($client->id); ?>">
                                                <h4 class="user-name text-info fw-bold mb-0">
                                                    <?php echo e($client->lastname . ' ' . $client->firstname); ?> </h4>
                                            </a>
                                            <span class="badge bg-secondary"><?php echo e($client->phone); ?></span>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
    <script></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mvic\resources\views/admin/new_client.blade.php ENDPATH**/ ?>