
<?php $__env->startSection('page_title'); ?>
    Manage Invoices Payments
<?php $__env->stopSection(); ?>


<?php $__env->startSection('page_content'); ?>
    <div class="row">
        <div class="col-lg-12 col-md-12 col-12">
            <div class=" pb-4 mb-2 d-flex justify-content-between align-items-center">
                <div class="mb-2 mb-lg-0">
                    <h1 class="mb-1 h2 fw-bold">
                        Invoices Payments
                    </h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">
                                Invoices Payments
                            </li>
                        </ol>
                    </nav>
                </div>

                <div class="d-flex">

                </div>


            </div>
        </div>



        <div class="col-12">

            <div class="card mb-3">
                <div class="card-body">
                    <h4 class="fw-bold">Regsiter New Payment</h4>
                    <form action="/register_payment" method="post"><?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-2 mb-3 mb-2 ">
                                <label class="form-label">Invoice Number <span class="text-danger">*</span> </label>
                                <input type="text" name="invoice_number" value="<?php echo e(old('invoice_number')); ?>"
                                    placeholder="enter invoice number " class="form-control">

                                <?php $__errorArgs = ['invoice_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-dnager small"> <?php echo e($message); ?> </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>


                            <div class="col-md-2 mb-3 mb-2 ">
                                <label class="form-label">Total Amount <span class="text-danger">*</span> </label>
                                <input type="text" name="total" value="<?php echo e(old('total')); ?>" placeholder=" " readonly
                                    class="form-control">

                                <?php $__errorArgs = ['total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-dnager small"> <?php echo e($message); ?> </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-2 mb-3 mb-2 ">
                                <label class="form-label">Paid <span class="text-danger">*</span> </label>
                                <input type="text" name="paid" placeholder=" " class="form-control" readonly>
                            </div>

                            <div class="col-md-2 mb-3 mb-2 ">
                                <label class="form-label">Amount <span class="text-danger">*</span> </label>

                                <input type="number" class="form-control" name="amount" value="<?php echo e(old('amount')); ?>">

                                <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-dnager small"> <?php echo e($message); ?> </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="col-md-2 mb-3 mb-2 ">
                                <label class="form-label">Payment Type <span class="text-danger">*</span> </label>
                                <select name="payment_type" class="form-control" required>
                                    <option selected disabled></option>
                                    <option> Pos </option>
                                    <option> Cash </option>
                                    <option> Transfer </option>
                                    <option> Cheque Book </option>
                                </select>

                                <?php $__errorArgs = ['payment_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-dnager small"> <?php echo e($message); ?> </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>


                            <div class="col-md-2 mb-3 mb-2 ">
                                <label class="form-label">Ref <span class="text-danger">*</span> </label>
                                <input type="text" name="ref" value="<?php echo e(old('rf')); ?>" placeholder=" "
                                    class="form-control">

                                <?php $__errorArgs = ['ref'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="text-dnager small"> <?php echo e($message); ?> </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>


                            <div class="col-md-12">
                                <div class="d-flex justify-content-end ">
                                    <button class="btn btn-primary">Register Payment</button>
                                </div>
                            </div>

                        </div>
                    </form>
                </div>
            </div>
            <div class="card mb-3">
                <div class="card-body">
                    <div class="row">
                        <div class="col-xl-4 col-lg-6 col-md-12 col-12">
                            <div class="card shadow-lg " style="border: 0">
                                <div class="card-body">
                                    <div class="d-flex align-items-center justify-content-between  lh-1">
                                        <div>
                                            <span class="fe fe-shopping-bag fs-4 text-primary"></span>

                                            <span class="fs-4  fw-semi-bold">Register Payments</span>
                                        </div>
                                        <div>
                                            <h2 class="fw-bold mb-1">
                                                <?php echo e(number_format(\App\Models\Payment::count())); ?>

                                            </h2>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>


                        <div class="col-xl-4 col-lg-6 col-md-12 col-12">
                            <div class="card shadow-lg " style="border: 0">
                                <div class="card-body">
                                    <div class="d-flex align-items-center justify-content-between  lh-1">
                                        <div>
                                            <span class="fe fe-shopping-bag fs-4 text-primary"></span>

                                            <span class="fs-4  fw-semi-bold">Today's Payment</span>
                                        </div>
                                        <div>
                                            <h2 class="fw-bold mb-1">
                                                <?php echo e(money($today_pay)); ?>

                                            </h2>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>


                        <div class="col-xl-4 col-lg-6 col-md-12 col-12">
                            <div class="card shadow-lg " style="border: 0">
                                <div class="card-body">
                                    <div class="d-flex align-items-center justify-content-between  lh-1">
                                        <div>
                                            <span class="fe fe-shopping-bag fs-4 text-primary"></span>

                                            <span class="fs-4  fw-semi-bold">Total Amount</span>
                                        </div>
                                        <div>
                                            <h2 class="fw-bold mb-1">
                                                <?php echo e(money(\App\Models\Payment::sum('amount'))); ?>

                                            </h2>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="mb-3">
                        <h4 class="card-title fw-bold">Payments</h4>
                    </div>

                    <div class="table-responsive shadow-lg ">
                        <table class="table table-sm ">
                            <thead>
                                <tr>
                                    <th>Client Name</th>
                                    <th>Invoice Number</th>
                                    <th>Amount</th>
                                    <th>Payment <br> Type</th>
                                    <th>By</th>
                                    <th>

                                        Date
                                    </th>
                                    <th></th>
                                </tr>
                            </thead>

                            <tbody>

                                <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="align-middle">
                                            <a href="/client/<?php echo e($pay->client->id); ?>">
                                                <h4 class="fw-bold m-0 small p-0 text-info">
                                                    <?php echo e($pay->client->lastname . ' ' . $pay->client->firstname); ?>

                                                </h4>
                                            </a>
                                        </td>

                                        <td class="align-middle fw-bold">
                                            <?php echo e($pay->invoice->invoice_number); ?>

                                        </td>

                                        <td class="align-middle fw-bold">
                                            <?php echo e(money($pay->amount)); ?>

                                        </td>


                                        <td class="align-middle fw-bold">
                                            <?php echo e($pay->payment_type); ?>

                                        </td>


                                        <td class="align-middle fw-bold">

                                            <a href="#">
                                                <h4 class="fw-bold m-0 small p-0 text-info">
                                                    <?php echo e($pay->user->name); ?>

                                                </h4>
                                            </a>
                                        </td>

                                        <td>
                                            <?php echo e(date('j M Y', strtotime($pay->created_at))); ?>

                                        </td>

                                        <td class="align-middle">

                                            <div class="d-flex justify-content-between ">
                                                <span> <?php echo e($pay->ref); ?> </span>
                                                <div class="d-flex mt-1">
                                                    <a href="/delete_payment/<?php echo e($pay->id); ?>" class=" "
                                                        onclick="return confirm('Payment will be deleted')">
                                                        <span class="badge bg-danger "
                                                            title="deleted invoice">delete</span>
                                                    </a>
                                                </div>
                                            </div>
                                        </td>

                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                    <div class="d-flex justify-content-end mt-3 ">
                        <?php echo e($payments->links('pagination::bootstrap-4')); ?>

                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>



<?php $__env->startPush('scripts'); ?>
    <script>
        $(function() {
            $('input[name="invoice_number"]').on('change', function() {
                invoice = $(this).val();
                $.ajax({
                    method: 'get',
                    url: `/search_invoice/${invoice}`
                }).done(function(res) {

                    $('input[name="total"]').val(res.total)
                    $('input[name="paid"]').val(res.total_paid)
                    $('input[name="amount"]').val(res.total - res.total_paid)
                    console.log(res);
                })
            })
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mvic\resources\views/admin/payments.blade.php ENDPATH**/ ?>