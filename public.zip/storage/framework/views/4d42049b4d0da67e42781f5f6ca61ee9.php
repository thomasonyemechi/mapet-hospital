
<?php $__env->startSection('page_title'); ?>
    Stock Profile | <?php echo e($item->name); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_content'); ?>
    <div class="col-xl-12">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-12">
                <div class=" pb-4 mb-2 d-flex justify-content-between align-items-center">
                    <div class="mb-2 mb-lg-0">
                        <h1 class="mb-1 h2 fw-bold">
                            Item Profile
                        </h1>
                        <!-- Breadcrumb  -->
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="#">Items </a>
                                </li>
                                <li class="breadcrumb-item">
                                    <a href="#"><?php echo e($item->name); ?></a>
                                </li>
                            </ol>
                        </nav>
                    </div>
                    <div class="nav btn-group" role="tablist">
                        <button class="btn btn-outline-white  active" data-bs-toggle="tab" data-bs-target="#tabPaneGrid"
                            role="tab" aria-controls="tabPaneGrid" aria-selected="true">
                            Search Item
                        </button>
                    </div>
                </div>
            </div>



            <div class="col-md-4">
                <div class="card">
                    <div class="card-header d-flex justify-content-between  ">
                        <h5 class="mb-0 fw-bold ">General Item Details</h5>
                        <button class="btn btn-primary py-0">Update Info</button>
                    </div>

                    <div class="card-body">
                        <div class="text-center">
                            <img src="<?php echo e(Avatar::create($item->name)->toBase64()); ?>" />
                            <h2 class="fw-bold mt-2"> <?php echo e($item->name); ?> </h2>
                        </div>

                        <div class="d-flex justify-content-between border-bottom py-2">
                            <span>Pricing</span>
                            <span class="text-warning">
                                <?php echo e(money($item->price)); ?>

                            </span>
                        </div>
                        <div class="d-flex justify-content-between border-bottom py-2">
                            <span>Product Code</span>
                            <span>

                            </span>
                        </div>
                        <div class="d-flex justify-content-between border-bottom py-2">
                            <span>Description</span>
                            <span>
                                <?php echo e($item->description); ?>

                            </span>
                        </div>
                        <div class="d-flex justify-content-between border-bottom py-2">
                            <span>Created Date</span>
                            <span>
                                <?php echo e($item->created_at); ?>

                            </span>
                        </div>
                    </div>
                </div>


                <div class=" mt-4 ">
                    <button class="btn btn-danger " style="width: 100%">
                        <i class="fa fa-trash me-2"></i> Delete <?php echo e($item->name); ?>

                    </button>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <h5 class=" fw-bold ">Inventory Details</h5>
                        <div class="d-flex justify-content-between border-bottom py-2">
                            <span>Current Stock</span>
                            <span class="text-warning">
                                <?php echo e(money($item->price * $item->quantity)); ?>

                            </span>
                        </div>
                        <div class="d-flex justify-content-between border-bottom py-2">
                            <span>Restock Quantity</span>
                            <span>
                                <?php echo e(number_format($item->quantity)); ?>

                            </span>
                        </div>
                        <div class="d-flex justify-content-between border-bottom py-2">
                            <span>Bigest Sale</span>
                            <span>
                                
                            </span>
                        </div>

                        <div class="d-flex justify-content-between border-bottom py-2">
                            <span>Total Sales</span>
                            <span class="fw-bold">
                                <?php echo e(money(App\Models\Sales::where(['item_id' => $item->id])->sum('price'))); ?>

                                |
                                <?php echo e(number_format(App\Models\Sales::where(['item_id' => $item->id])->sum('quantity'))); ?> pcs
                            </span>
                        </div>
                        
                        <div class="d-flex justify-content-between border-bottom py-2">
                            <span>Restock Summary</span>
                            <span class="fw-bold">
                                <?php echo e(number_format(App\Models\Restock::where(['item_id' => $item->id])->sum('quantity'))); ?> pcs
                            </span>
                        </div>
                    </div>
                </div>


                <div class="card mt-3">
                    <div class="card-body">
                        <div class="d-flex justify-content-between ">
                            <div>
                                <h5 class="mb-0">Product Catrgory</h5>
                                <h3 class="fw-bold mb-0 mt-0"> <?php echo e($item->category->category); ?> </h3>
                            </div>
                            <div>
                                <h5 class="mb-0">Brand </h5>
                                <h3 class="fw-bold mb-0 mt-0"> <?php echo e($item->brand); ?> </h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex  justify-content-between ">
                            <h5 class="fw-bold">Recent Sales</h5>
                            <a href="/admin/stock/sales/<?php echo e($item->id); ?>" class="align-middle">See All</a>
                        </div>
                        <table class="table table-sm mt-2 p-0 ">
                            <thead>
                                <tr>
                                    <th>Qty</th>
                                    <th>Total</th>
                                    <th>Date</th>
                                    <td></td>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $recent_sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td> <?php echo e($sale->quantity); ?> </td>
                                        <td> <?php echo e(money($sale->price)); ?> </td>
                                        <td> <?php echo e($sale->created_at); ?> </td>
                                        <td>
                                            <a href="" class="text-danger"> <i class="fa fa-trash "></i> </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="card mt-3">
                    <div class="card-body">
                        <div class="d-flex  justify-content-between ">
                            <h5 class="fw-bold">Restock History</h5>
                            <a href="/admin/stock/restock/<?php echo e($item->id); ?>" class="align-middle">See All</a>
                        </div>
                        <table class="table table-sm mt-2 p-0 ">
                            <thead>
                                <tr>
                                    <th>Qty</th>
                                    <th>Total</th>
                                    <th>Date</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $restock_histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $restock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td> <?php echo e($restock->quantity); ?> </td>
                                    <td> <?php echo e(money($restock->price * $restock->quantity)); ?> </td>
                                    <td> <?php echo e($restock->created_at); ?> </td>
                                    <td>
                                        <a href="" class="text-danger"> <i class="fa fa-trash "></i> </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>



            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SalesSphere\resources\views/admin/item_profile.blade.php ENDPATH**/ ?>