<?php

namespace App\Http\Controllers;

use App\Models\Admission;
use App\Models\Client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class AdmissionController extends Controller
{
    function admissionIndex(Request $request)
    {
        $client = '';
        if($request->client) {
            $client = Client::findorFail($request->client);
        }
        return view('admin.new_admission', compact(['client']) );
    }


    function manageIndex(Request $request)
    {
        $admisions = Admission::orderby('id', 'desc')->paginate(45);
        return view('admin.manage_admissions', compact(['admisions']));
    }


    function newAdmisison(Request $request)
    {
        Validator::make($request->all(), [
            'weight' => 'required|string',
            'height' => 'required|string',
            'blood_pressure' => 'required|string',
            'clinical_concerns' =>'required|string',
        ])->validate();

        $client_id = $this->updateOrCreatePatient($request);
        
        Admission::create([
            'client_id' => $client_id,
            'user_id' => auth()->user()->id,
            'blood_pressure' => $request->blood_pressure,
            'clinical_concerns' => $request->clinical_concerns,
            'weight' => $request->weight,
            'height' => $request->height,
            'date' => $request->arrival_date_time ?? now(),
        ]);

        return back()->with('success', 'Admission Info has been sucessfully added');
    }
}
